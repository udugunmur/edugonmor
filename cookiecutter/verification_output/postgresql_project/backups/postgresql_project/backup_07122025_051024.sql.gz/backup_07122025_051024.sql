--
-- PostgreSQL database cluster dump
--

\restrict 8S1W0F8OcPZEppYFens031h5Coda7OpiAukkdRYkDbX2LUhfoQfl0JMMd9QxxyX

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--

DROP DATABASE IF EXISTS penpot_db;




--
-- Drop roles
--

DROP ROLE IF EXISTS app_reader;
DROP ROLE IF EXISTS app_writer;
DROP ROLE IF EXISTS penpot_user;
DROP ROLE IF EXISTS postgres;


--
-- Roles
--

CREATE ROLE app_reader;
ALTER ROLE app_reader WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB NOLOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE app_writer;
ALTER ROLE app_writer WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB NOLOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE penpot_user;
ALTER ROLE penpot_user WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:MSzi+ou+J7IsDb+Ms/SWDw==$iwh8fyE79Tcy3A0Mp9JGCTPZ5naPrb+ObZGxqWAUskY=:CKOVoilLu9AwCgOzLT1rPhxQKe0lFmvVSJc3CsZHmcs=';
CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:s1W0XuM5iBJ6BApd/xwRXw==$didFhlp7J5Fzon++oZmDrafpdU0/nSld+ATF59S/e9w=:3NOiThaq+U28LZPJxJEN1emUjPefuqqWgstmLjhRLRo=';

--
-- User Configurations
--


--
-- Role memberships
--

GRANT app_writer TO penpot_user WITH INHERIT TRUE GRANTED BY postgres;






\unrestrict 8S1W0F8OcPZEppYFens031h5Coda7OpiAukkdRYkDbX2LUhfoQfl0JMMd9QxxyX

--
-- Databases
--

--
-- Database "template1" dump
--

--
-- PostgreSQL database dump
--

\restrict vvhmr5Dura16IQZKq3Owq4FbYBiBDwaqcuwLoiP3pgCRGhFhqWS7VHxYzPOTUzn

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg13+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

UPDATE pg_catalog.pg_database SET datistemplate = false WHERE datname = 'template1';
DROP DATABASE template1;
--
-- Name: template1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE template1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE template1 OWNER TO postgres;

\unrestrict vvhmr5Dura16IQZKq3Owq4FbYBiBDwaqcuwLoiP3pgCRGhFhqWS7VHxYzPOTUzn
\connect template1
\restrict vvhmr5Dura16IQZKq3Owq4FbYBiBDwaqcuwLoiP3pgCRGhFhqWS7VHxYzPOTUzn

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE template1 IS 'default template for new databases';


--
-- Name: template1; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE template1 IS_TEMPLATE = true;


\unrestrict vvhmr5Dura16IQZKq3Owq4FbYBiBDwaqcuwLoiP3pgCRGhFhqWS7VHxYzPOTUzn
\connect template1
\restrict vvhmr5Dura16IQZKq3Owq4FbYBiBDwaqcuwLoiP3pgCRGhFhqWS7VHxYzPOTUzn

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: ACL; Schema: -; Owner: postgres
--

REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict vvhmr5Dura16IQZKq3Owq4FbYBiBDwaqcuwLoiP3pgCRGhFhqWS7VHxYzPOTUzn

--
-- Database "penpot_db" dump
--

--
-- PostgreSQL database dump
--

\restrict 4j0OrhfxOuRS9fxamOLzlfDmC51k1M5G3lguCKQ94feReiR8USpXaYUSvLCt0UN

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg13+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: penpot_db; Type: DATABASE; Schema: -; Owner: penpot_user
--

CREATE DATABASE penpot_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE penpot_db OWNER TO penpot_user;

\unrestrict 4j0OrhfxOuRS9fxamOLzlfDmC51k1M5G3lguCKQ94feReiR8USpXaYUSvLCt0UN
\connect penpot_db
\restrict 4j0OrhfxOuRS9fxamOLzlfDmC51k1M5G3lguCKQ94feReiR8USpXaYUSvLCt0UN

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 4j0OrhfxOuRS9fxamOLzlfDmC51k1M5G3lguCKQ94feReiR8USpXaYUSvLCt0UN

--
-- Database "postgres" dump
--

--
-- PostgreSQL database dump
--

\restrict Hsr42g0n9K5zQwxahaEo1remKDs0NmWYT4AYVbbyHWlpebVXkygn8cEf536QOwC

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg13+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE postgres OWNER TO postgres;

\unrestrict Hsr42g0n9K5zQwxahaEo1remKDs0NmWYT4AYVbbyHWlpebVXkygn8cEf536QOwC
\connect postgres
\restrict Hsr42g0n9K5zQwxahaEo1remKDs0NmWYT4AYVbbyHWlpebVXkygn8cEf536QOwC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- PostgreSQL database dump complete
--

\unrestrict Hsr42g0n9K5zQwxahaEo1remKDs0NmWYT4AYVbbyHWlpebVXkygn8cEf536QOwC

--
-- PostgreSQL database cluster dump complete
--

